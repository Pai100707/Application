import io
import sys

def RunHandler(code):
    # raise RuntimeError("RunHandler.py failed to run without module.")
    old_stdout = sys.stdout
    sys.stdout = io.StringIO()
    globals_env = {}

    try:
        exec(code, globals_env)
        output = sys.stdout.getvalue().strip()
    except Exception as e:
        output = f"Error: {e}"
    finally:
        sys.stdout = old_stdout

    return output
