import sys
import io

def RunHandler(code, callback=None):
    old_stdout = sys.stdout
    old_stderr = sys.stderr
    sys.stdout = io.StringIO()
    sys.stderr = io.StringIO()
    globals_env = {}

    def flush_output():
        if callback:
            out = sys.stdout.getvalue()
            err = sys.stderr.getvalue()
            if out:
                callback(out)
                sys.stdout = io.StringIO()
            if err:
                callback(err)
                sys.stderr = io.StringIO()

    try:
        lines = code.splitlines()
        for line in lines:
            try:
                exec(line, globals_env)
            except Exception as e:
                if callback:
                    callback(f"{e}\n")
                else:
                    return f"{e}"
            finally:
                flush_output()
    finally:
        if not callback:
            output = sys.stdout.getvalue()
            err = sys.stderr.getvalue()
            sys.stdout = old_stdout
            sys.stderr = old_stderr
            return output + err
        sys.stdout = old_stdout
        sys.stderr = old_stderr
