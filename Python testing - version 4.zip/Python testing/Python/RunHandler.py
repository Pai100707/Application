import sys

class StdoutRedirector:
    def __init__(self, callback=None):
        self.callback = callback
        self.buffer = ""

    def write(self, text):
        self.buffer += text
        if self.callback:
            self.callback(text)

    def flush(self):
        pass

def RunHandler(code, callback=None):  # callback default = None
    """
    code     : string โค้ด Python ที่ต้องรัน
    callback : ฟังก์ชันสำหรับ real-time output (optional)
    """
    old_stdout = sys.stdout
    redirector = StdoutRedirector(callback)
    sys.stdout = redirector
    globals_env = {}

    output = ""
    try:
        exec(code, globals_env)
        output = redirector.buffer.strip()
    except Exception as e:
        output = f"Error: {e}"
    finally:
        sys.stdout = old_stdout

    return output
